# Sample online shop

Made with Next.js, TailwindCSS, Prisma, DaisyUI, TRPC and Stripe.

Bootstrapped with create-t3-app.

Work in progress.