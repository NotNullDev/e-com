export const IMAGE_URL_PREFIX = process.env.IMAGE_URL_PREFIX || "";
