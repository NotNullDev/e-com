#!/bin/sh
env

ls
node .next/standalone/server.js